from flask import Flask,render_template,request,redirect,session

from cs50 import SQL
from flask_session import Session
app = Flask(__name__)

#app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

db = SQL("sqlite:///announceMe.db")
@app.route("/")
def index():
    return redirect("/login")

@app.route("/group",methods = ["GET","POST"])
def group():
    if request.method == "GET":
        groups=db.execute("SELECT grp.groupName,members.groupId FROM members INNER JOIN grp ON members.groupId = grp.groupId WHERE members.userName=:userName ",userName=session["userName"])
        return render_template("groups.html",groups=groups)
    else:
        if request.form.get("groupId"):
            checkRow = db.execute("SELECT * FROM members WHERE groupId=:groupId AND userName=:userName",groupId=request.form.get("groupId"),userName=session["userName"])
            if len(checkRow)==0:
                return render_template("apology.html",message="Group Doesn't exist For you")
            else:
                session["groupId"] = request.form.get("groupId")
                return redirect("/posts")
        elif request.form.get("groupName"):#create group
            checksum = db.execute("SELECT * FROM grp WHERE groupName=:groupName",groupName=request.form.get("groupName"))
            if len(checksum)==0:
                db.execute("INSERT INTO grp (groupName) VALUES (:groupName)",groupName=request.form.get("groupName"))
                groupId=db.execute("SELECT groupId FROM grp WHERE groupName=:groupName",groupName=request.form.get("groupName"))
                db.execute("INSERT INTO members (groupId,userName) VALUES (:groupId,:userName)",groupId=groupId[0]["groupId"],userName=session["userName"])
                return redirect("/group")
            else:
                return render_template("apology.html",message="Group already exists!!")
        elif request.form.get("groupToJoin"):#join group
            check = db.execute("SELECT * FROM grp WHERE groupName=:groupName",groupName=request.form.get("groupToJoin"))
            if len(check) == 0:
                return render_template("apology.html",message="There is no such group to join")
            else:
                id = db.execute("SELECT groupId FROM grp where groupName=:groupName",groupName=request.form.get("groupToJoin"))
                db.execute("INSERT INTO members (groupId,userName) VALUES (:groupId,:userName)",groupId=id[0]["groupId"],userName=session["userName"])
                return redirect("/group")

@app.route("/posts",methods=["GET","POST"])
def posts():
    if request.method == "POST":
        if request.form.get("like"):
             postId = request.form.get("like")
             tada = db.execute("SELECT * FROM liked WHERE postId=:postId AND likedBy=:likedBy",postId=postId,likedBy=session["userName"])
             if len(tada) == 0:
                 db.execute("INSERT INTO liked(postId,likedBy) VALUES (:postId,:likedBy)",postId=postId,likedBy=session["userName"])
             else:
                 db.execute("DELETE FROM liked WHERE likedBy=:likedBy AND postId=:postId",likedBy=session["userName"],postId=postId)
             return redirect("/posts")
        elif request.form.get("comment"):
            comment = request.form.get("comment")
            commentedPostId = request.form.get("commentedPostId")
            db.execute("INSERT INTO commented(postId,commentedBy,comment) VALUES (:postId,:commentedBy,:comment)",postId=commentedPostId,commentedBy=session["userName"],comment=comment)
            return redirect("/posts")
        elif request.form.get("comments"):
            postId = request.form.get("comments")
            comments = db.execute("SELECT commentedBy,comment FROM commented WHERE postId=:postId",postId=postId)
            return render_template("comments.html",comments=comments)
        elif request.form.get("post"):
            post = request.form.get("post")
            db.execute("INSERT INTO posts (postedBy,postedAt,groupId,post) VALUES (:postedBy,DateTime('now'),:groupId,:post)",postedBy=session["userName"],groupId=session["groupId"],post=post)
            return redirect("/posts")
    else:
        thisUserLikes = db.execute("SELECT postId FROM liked WHERE likedBy=:likedBy",likedBy=session["userName"])
        likes = db.execute("SELECT COUNT(likedBy) numberOfLikes,postId FROM liked GROUP BY postId")
        posts = db.execute("SELECT postId,postedBy,postedAt,post FROM  posts  WHERE groupId=:groupId ORDER BY postedAt DESC",groupId=session["groupId"])
        return render_template("group.html",posts=posts,likes=likes,thisUserLikes=thisUserLikes)


@app.route("/login",methods=["GET","POST"])
def logIn():
    session.clear()
    if request.method == 'POST':
        if not request.form.get("userName"):
            return render_template("apology.html",message="Enter username")
        elif not request.form.get("password"):
            return render_template("apology.html",message ="Enter password")
        rows = db.execute("SELECT * FROM user WHERE userName=:userName AND password=:password",userName=request.form.get("userName"),password=request.form.get("password"))
        if len(rows) != 1:
            return redirect("/signup")
        session["userName"] = rows[0]["userName"]
        return redirect("/group")
    else:
        return render_template("login.html")


@app.route("/logout")
def logOut():
    session.clear()
    return redirect("/login")



@app.route("/signup",methods=["GET","POST"])
def signUp():
    userNames = db.execute("SELECT userName FROM user")
    if request.method == "GET":
        return render_template("signUp.html")
    else:
        if not request.form.get("firstName"):
            return render_template("apology.html",message = "Enter first Name")
        elif not request.form.get("lastName"):
            return render_template("apology.html",message="Enter last Name")
        elif not request.form.get("userName"):
            return render_template("apology.html",message="Enter userName")
        elif not request.form.get("password"):
            return render_template("apology.html",message="Enter password")
        elif request.form.get("userName") in userNames:
            return render_template("apology.html",message="UserName already taken")
        else:
            db.execute("INSERT INTO user (firstName,lastName,userName,password) VALUES (:firstName,:lastName,:userName,:password)",firstName=request.form.get("firstName"),lastName=request.form.get("lastName"),userName=request.form.get("userName"),password=request.form.get("password"))
            return render_template("success.html")


